FREEDOM AI TRADER — FRESH PROJECT

Yeh ek naya, saaf Android project hai. Is ZIP mein purane project ki files shamil nahi hain.

ABHI IS VERSION MEIN:
- Android app shell, black/gold theme
- CoinGecko se INR mein top 50 market watchlist
- 24-hour price movement
- Capital aur maximum-loss calculator
- Manual trading only; koi auto-order execution nahi

ABHI IS VERSION MEIN NAHI HAI:
- Trained AI/ML model ya profit prediction
- SunCrypto live socket integration
- EMA/RSI/Supertrend ka complete live signal engine
- Support/resistance, unlock schedule, backers/team/community scoring
- Exchange login/API trading

APK BUILD:
1. ZIP ko extract karna zaroori hai.
2. ZIP ke ANDAR ke saare files/folders repository ke ROOT mein upload karein.
3. GitHub repo ka default branch main hona chahiye.
4. Actions tab > Build Freedom AI Trader APK > Run workflow.
5. Green run ke baad Artifacts se freedom-ai-trader-debug-apk download karein.
6. ZIP artifact extract karke app-debug.apk Android par install karein.

IMPORTANT:
- GitHub par ZIP ko sirf upload karne se woh extract nahi hoti.
- Existing repo mein purani files overwrite/replace hongi only if same paths selected.
- Better: is fresh project ko ek NEW empty GitHub repository mein upload karein, taaki old files mix na hon.
- Yeh debug APK hai, Play Store release-signed APK nahi.
- CoinGecko public API rate limit ya network issue ki wajah se market list kabhi fail ho sakti hai.
