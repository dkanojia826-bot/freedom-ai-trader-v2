import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, RefreshControl, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Coin, fetchMarket } from "./src/market";

const gold = "#e4b64f";
const money = (n: number) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 4 });
const pct = (n: number) => `${n >= 0 ? "+" : ""}${(n || 0).toFixed(2)}%`;

export default function App() {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("MARKET");
  const [capital, setCapital] = useState(5000);
  const [risk, setRisk] = useState(1);

  async function load() {
    setError("");
    try { setCoins(await fetchMarket()); }
    catch (e: any) { setError(e?.message || "Could not load market data."); }
    finally { setLoading(false); setRefreshing(false); }
  }
  useEffect(() => { load(); }, []);

  const movers = useMemo(() => [...coins].sort((a,b) => (b.price_change_percentage_24h || 0) - (a.price_change_percentage_24h || 0)).slice(0, 10), [coins]);
  const loss = capital * risk / 100;

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#080b12" />
      <View style={s.header}>
        <View>
          <Text style={s.brand}>FREEDOM <Text style={{color:gold}}>AI TRADER</Text></Text>
          <Text style={s.sub}>MARKET INTELLIGENCE • MANUAL TRADING</Text>
        </View>
        <Text style={s.om}>ॐ</Text>
      </View>
      <View style={s.tabs}>
        {["MARKET","RISK","ABOUT"].map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={[s.tab, tab===t && s.activeTab]}><Text style={[s.tabText,tab===t&&{color:gold}]}>{t}</Text></TouchableOpacity>)}
      </View>
      {tab === "MARKET" && <View style={{flex:1}}>
        <View style={s.hero}>
          <Text style={s.label}>MARKET WATCHLIST</Text>
          <Text style={s.heroTitle}>Top 50 coins by market cap</Text>
          <Text style={s.muted}>Live INR quotes • Data from CoinGecko</Text>
        </View>
        {loading ? <ActivityIndicator color={gold} size="large" style={{marginTop:40}} /> :
          <FlatList data={movers} keyExtractor={x=>x.id} refreshControl={<RefreshControl tintColor={gold} refreshing={refreshing} onRefresh={()=>{setRefreshing(true);load();}}/>}
            ListEmptyComponent={<Text style={s.error}>{error || "No market data available."}</Text>}
            renderItem={({item,index})=><View style={s.coin}>
              <View style={s.rank}><Text style={s.rankText}>{index+1}</Text></View>
              <View style={{flex:1}}>
                <Text style={s.coinName}>{item.name}</Text>
                <Text style={s.symbol}>{item.symbol.toUpperCase()} • MCap {money(item.market_cap)}</Text>
              </View>
              <View style={{alignItems:"flex-end"}}>
                <Text style={s.price}>{money(item.current_price)}</Text>
                <Text style={{color:item.price_change_percentage_24h>=0?"#4bd49a":"#ff6b6b",fontWeight:"700"}}>{pct(item.price_change_percentage_24h)}</Text>
              </View>
            </View>}
            ListFooterComponent={<Text style={s.foot}>Signals are informational only. Verify prices and liquidity on your exchange before trading.</Text>}
          />}
        {!!error && <Text style={s.error}>{error}</Text>}
      </View>}
      {tab === "RISK" && <ScrollView contentContainerStyle={{padding:18}}>
        <Text style={s.section}>TRADE RISK CALCULATOR</Text>
        <Text style={s.muted}>Set your capital and maximum loss percentage.</Text>
        <View style={s.panel}>
          <Text style={s.label}>TRADING CAPITAL</Text><Text style={s.big}>{money(capital)}</Text>
          <View style={s.row}>{[2000,5000,10000,25000].map(v=><TouchableOpacity key={v} onPress={()=>setCapital(v)} style={[s.choice,capital===v&&s.choiceOn]}><Text style={s.choiceText}>₹{v.toLocaleString("en-IN")}</Text></TouchableOpacity>)}</View>
          <Text style={[s.label,{marginTop:22}]}>MAXIMUM LOSS</Text><Text style={s.big}>{risk}% = <Text style={{color:"#ff7979"}}>{money(loss)}</Text></Text>
          <View style={s.row}>{[0.5,1,2,3].map(v=><TouchableOpacity key={v} onPress={()=>setRisk(v)} style={[s.choice,risk===v&&s.choiceOn]}><Text style={s.choiceText}>{v}%</Text></TouchableOpacity>)}</View>
        </View>
        <Text style={s.foot}>This calculator does not place orders or connect to your exchange account.</Text>
      </ScrollView>}
      {tab === "ABOUT" && <ScrollView contentContainerStyle={{padding:18}}>
        <Text style={s.section}>FREEDOM AI TRADER</Text>
        <Text style={s.about}>A standalone market-watch and risk-planning prototype for manual crypto trading.</Text>
        {["INR market watchlist","24-hour price movement","Capital and loss calculator","Manual trading only","No exchange order execution"].map(x=><Text key={x} style={s.feature}>✓  {x}</Text>)}
        <View style={s.panel}><Text style={s.label}>IMPORTANT</Text><Text style={s.muted}>This version uses public CoinGecko market data and simple display tools. It is not a trained AI model and does not guarantee profit. EMA/RSI, Supertrend, support/resistance, token unlock and project-fundamental analysis are not yet included in this starter build.</Text></View>
      </ScrollView>}
      <Text style={s.bottom}>HAR HAR MAHADEV  •  TRADE WITH DISCIPLINE</Text>
    </SafeAreaView>
  );
}

const s=StyleSheet.create({
  safe:{flex:1,backgroundColor:"#080b12"},
  header:{paddingHorizontal:18,paddingTop:18,paddingBottom:15,flexDirection:"row",justifyContent:"space-between",alignItems:"center",borderBottomWidth:1,borderColor:"#242b37"},
  brand:{color:"#fff",fontSize:20,fontWeight:"900",letterSpacing:1},
  sub:{color:"#8993a4",fontSize:9,letterSpacing:1.3,marginTop:5},
  om:{color:gold,fontSize:34,fontWeight:"bold"},
  tabs:{flexDirection:"row",paddingHorizontal:14,borderBottomWidth:1,borderColor:"#242b37"},
  tab:{paddingVertical:14,paddingHorizontal:16,borderBottomWidth:2,borderColor:"transparent"},
  activeTab:{borderColor:gold},tabText:{color:"#8b95a5",fontWeight:"800",fontSize:11,letterSpacing:1},
  hero:{padding:18},label:{color:gold,fontSize:10,fontWeight:"800",letterSpacing:1.5},
  heroTitle:{color:"#fff",fontSize:21,fontWeight:"800",marginTop:8},
  muted:{color:"#98a2b3",fontSize:12,lineHeight:19,marginTop:5},
  coin:{marginHorizontal:14,paddingVertical:14,paddingHorizontal:10,borderBottomWidth:1,borderColor:"#202734",flexDirection:"row",alignItems:"center"},
  rank:{width:27,height:27,borderRadius:8,backgroundColor:"#1b2330",alignItems:"center",justifyContent:"center",marginRight:10},
  rankText:{color:gold,fontWeight:"800",fontSize:11},coinName:{color:"#fff",fontWeight:"700",fontSize:14},
  symbol:{color:"#8792a4",fontSize:10,marginTop:4},price:{color:"#fff",fontWeight:"800",fontSize:13,marginBottom:4},
  error:{color:"#ff8585",padding:16,textAlign:"center"},foot:{color:"#7e899a",fontSize:10,lineHeight:16,padding:18},
  section:{color:gold,fontWeight:"900",fontSize:14,letterSpacing:1.2,marginBottom:8},
  panel:{backgroundColor:"#111925",borderWidth:1,borderColor:"#293345",borderRadius:14,padding:16,marginTop:18},
  big:{color:"#fff",fontSize:25,fontWeight:"900",marginTop:9},
  row:{flexDirection:"row",flexWrap:"wrap",gap:8,marginTop:15},
  choice:{borderWidth:1,borderColor:"#3b4658",paddingVertical:10,paddingHorizontal:13,borderRadius:9},
  choiceOn:{borderColor:gold,backgroundColor:"#302817"},choiceText:{color:"#fff",fontWeight:"700",fontSize:12},
  about:{color:"#dce2eb",fontSize:15,lineHeight:23,marginVertical:12},
  feature:{color:"#dce2eb",fontSize:13,paddingVertical:9,borderBottomWidth:1,borderColor:"#202734"},
  bottom:{textAlign:"center",color:"#7f6b3c",fontSize:9,letterSpacing:1.5,paddingVertical:12,borderTopWidth:1,borderColor:"#202734"}
});
