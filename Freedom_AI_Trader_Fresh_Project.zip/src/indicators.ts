export type Candle = { close: number; high: number; low: number; volume: number };

export function ema(values: number[], period: number): number | null {
  if (values.length < period) return null;
  const k = 2 / (period + 1);
  let result = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) result = values[i] * k + result * (1 - k);
  return result;
}

export function rsi(values: number[], period = 14): number | null {
  if (values.length <= period) return null;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const change = values[i] - values[i - 1];
    if (change >= 0) gains += change; else losses -= change;
  }
  let avgGain = gains / period, avgLoss = losses / period;
  for (let i = period + 1; i < values.length; i++) {
    const change = values[i] - values[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(change, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-change, 0)) / period;
  }
  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

export function signalFor(closes: number[]) {
  const fast = ema(closes, 7);
  const slow = ema(closes, 30);
  const long = ema(closes, 200);
  const strength = rsi(closes);
  if (fast === null || slow === null || strength === null) return "WAIT";
  if (fast > slow && strength >= 50 && (long === null || closes[closes.length - 1] > long)) return "BUY WATCH";
  if (fast < slow && strength < 48) return "AVOID";
  return "WAIT";
}
