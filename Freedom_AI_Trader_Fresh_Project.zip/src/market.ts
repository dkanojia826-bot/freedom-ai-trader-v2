export type Coin = {
  id: string; symbol: string; name: string;
  current_price: number; price_change_percentage_24h: number;
  market_cap: number; total_volume: number;
};

const API = "https://api.coingecko.com/api/v3";

export async function fetchMarket(): Promise<Coin[]> {
  const url = `${API}/coins/markets?vs_currency=inr&order=market_cap_desc&per_page=50&page=1&sparkline=false&price_change_percentage=24h`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Market data error (${response.status}). Please retry.`);
  return response.json();
}

export async function fetchHistory(id: string): Promise<number[]> {
  const response = await fetch(`${API}/coins/${encodeURIComponent(id)}/market_chart?vs_currency=inr&days=30&interval=daily`);
  if (!response.ok) throw new Error("Unable to load coin history.");
  const data = await response.json();
  return (data.prices || []).map((p: [number, number]) => Number(p[1]));
}
