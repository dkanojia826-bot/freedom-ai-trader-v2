import React,{useEffect,useState} from "react";
import{SafeAreaView,ScrollView,View,Text,TouchableOpacity,ActivityIndicator,RefreshControl}from"react-native";
import{StatusBar}from"expo-status-bar";
import{getTickers,getCandles,getUsdInr,getActiveSource}from"./src/market";
import{analyze,Signal}from"./src/engine";
import{addTrade,readTrades}from"./src/storage";
const gold="#e4bd63",bg="#090b10",panel="#151922",muted="#a5adba";
export default function App(){
 const[signals,setSignals]=useState<Signal[]>([]),[rate,setRate]=useState(84),[busy,setBusy]=useState(false),[err,setErr]=useState(""),[source,setSource]=useState("Not connected"),[trades,setTrades]=useState<any[]>([]);
 async function load(){setBusy(true);setErr("");try{const[ticks,fx]=await Promise.all([getTickers(),getUsdInr()]);setRate(fx);setSource(getActiveSource());const ranked=ticks.sort((a,b)=>Math.abs(b.change)-Math.abs(a.change)).slice(0,30);const out:Signal[]=[];for(const t of ranked.slice(0,12)){try{out.push(analyze(t.symbol,await getCandles(t.symbol)));}catch{}}setSignals(out.sort((a,b)=>b.score-a.score));if(!out.length)setErr("Ticker data aaya, lekin kline format se candles parse nahi hue.");}catch(e:any){setErr(e?.message||"Market data unavailable");}setTrades(await readTrades());setBusy(false);}
 useEffect(()=>{load();},[]);
 async function paper(s:Signal){await addTrade({symbol:s.symbol,side:s.side,entry:s.entry,stop:s.stop,target:s.t1,status:"OPEN"});setTrades(await readTrades());}
 const best=signals.find(x=>x.side!=="WAIT"),money=(n:number)=>"₹"+(n*rate).toLocaleString("en-IN",{maximumFractionDigits:4});
 return <SafeAreaView style={{flex:1,backgroundColor:bg}}><StatusBar style="light"/><ScrollView contentContainerStyle={{padding:16}}refreshControl={<RefreshControl refreshing={busy}onRefresh={load}tintColor={gold}/>}>
 <Text style={{color:gold,fontSize:25,fontWeight:"900"}}>FREEDOM AI TRADER</Text><Text style={{color:muted,marginTop:4}}>SunCrypto-first market scanner · Paper trading</Text>
 <View style={{backgroundColor:panel,padding:14,borderRadius:14,marginTop:16}}><Text style={{color:muted}}>Market feed status</Text><Text style={{color:gold,fontSize:18,fontWeight:"bold"}}>{source}</Text><Text style={{color:muted}}>USD/INR reference: {rate.toFixed(2)}</Text></View>
 {!!err&&<Text style={{color:"#ff7777",marginTop:12}}>{err}</Text>}
 <Text style={{color:gold,fontSize:18,fontWeight:"bold",marginTop:20}}>BEST CURRENT SETUP</Text>
 {busy&&!signals.length?<ActivityIndicator color={gold}/>:best?<View style={{backgroundColor:panel,padding:14,borderRadius:14,marginTop:8}}><Text style={{color:"white",fontSize:20,fontWeight:"bold"}}>{best.symbol} · {best.side}</Text><Text style={{color:muted,marginTop:6}}>Entry {money(best.entry)} | SL {money(best.stop)}</Text><Text style={{color:muted}}>T1 {money(best.t1)} · T2 {money(best.t2)} · T3 {money(best.t3)}</Text><Text style={{color:muted,marginTop:6}}>Score {best.score} · {best.reason.join(" · ")}</Text><TouchableOpacity onPress={()=>paper(best)}style={{backgroundColor:gold,padding:10,borderRadius:9,marginTop:12}}><Text style={{color:bg,fontWeight:"bold",textAlign:"center"}}>ADD PAPER TRADE</Text></TouchableOpacity></View>:<Text style={{color:muted,marginTop:8}}>No setup confirmed. WAIT is valid.</Text>}
 <Text style={{color:gold,fontSize:18,fontWeight:"bold",marginTop:22}}>TOP OPPORTUNITIES</Text>{signals.slice(0,10).map((s,i)=><View key={s.symbol}style={{backgroundColor:panel,padding:12,borderRadius:10,marginTop:8}}><Text style={{color:"white",fontWeight:"bold"}}>{i+1}. {s.symbol} — {s.side}</Text><Text style={{color:muted}}>Price {money(s.price)} · Rule score {s.score}</Text></View>)}
 <Text style={{color:gold,fontSize:18,fontWeight:"bold",marginTop:22}}>PAPER TRADES ({trades.length})</Text>{trades.slice(0,10).map(t=><Text key={t.id}style={{color:muted,marginTop:8}}>{t.symbol} · {t.side} · {t.status} · {money(t.entry)}</Text>)}
 <Text style={{color:muted,fontSize:12,lineHeight:18,marginTop:24}}>API NOTE: App tries SunCrypto /tickerArr and /ticker first, then falls back to Binance if it cannot parse a usable response. It tries common kline query parameter forms; exact SunCrypto kline contract is not verified in this build. INR is an indicative USD conversion, not a SunCrypto INR quote. Experimental EMA/RSI/ATR rules only. No auto-orders; no profit or accuracy guarantee. Fundamentals, unlocks, verified backers/team/community, true Supertrend, BTC filter, alerts/countdown/expiry and robust historical backtesting remain unimplemented.</Text>
 </ScrollView></SafeAreaView>;
}
