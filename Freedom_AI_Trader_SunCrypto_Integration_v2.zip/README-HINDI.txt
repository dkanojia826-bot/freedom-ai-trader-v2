FREEDOM AI TRADER - DEVELOPMENT BUILD v1.0.1

SunCrypto integration attempt added:
- Tries /tickerArr then /ticker at the supplied API base.
- Normalizes likely ticker keys including s, c, P, h, l, v, q.
- Tries /kline using symbol+interval+limit, symbol+period+limit, and contract+interval+limit.
- Falls back to Binance when SunCrypto data is unreachable or unparseable.

IMPORTANT: Exact SunCrypto kline request/response schema is not verified, so this is an integration adapter attempt, not confirmed live connectivity. The app displays which ticker source it used. INR is an indicative USD conversion, not a SunCrypto INR quote.

Implemented: Android Expo app, scanner, EMA7/30/200, RSI, ATR, basic setup scoring, INR reference conversion, paper-trade logging, APK GitHub Actions workflow.

Still pending: verified complete SunCrypto contract, fundamentals, token unlocks/backers/team/community, true Supertrend, BTC trend filter, alerts/countdown/expiry/invalidation, target-time estimates, robust backtesting with fees/slippage.

Upload only if you are ready to test this development build. Keep a backup of your current GitHub files. This ZIP is source, not APK.
