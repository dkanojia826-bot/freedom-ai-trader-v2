import {Candle} from "./engine";
const SUN="https://sckt5-dev.suncrypto.in/api";
const BINANCE="https://api.binance.com";
export type Ticker={symbol:string;price:number;change:number;volume:number;source:"SunCrypto"|"Binance"};
let activeSource:"SunCrypto"|"Binance"="SunCrypto";
function rowsOf(j:any):any[]{if(Array.isArray(j))return j;for(const k of ["data","result","tickers","ticker","symbols","contracts"])if(Array.isArray(j?.[k]))return j[k];return [];}
function normalizeTicker(x:any,source:"SunCrypto"|"Binance"):Ticker|null{
 const symbol=String(x.symbol??x.s??x.contractName??x.pair??"").toUpperCase();
 const price=Number(x.lastPrice??x.marketPrice??x.c??x.price??x.close);
 if(!symbol||!Number.isFinite(price)||price<=0)return null;
 return{symbol,price,change:Number(x.priceChangePercent??x.P??x.changePercent??0),volume:Number(x.quoteVolume??x.q??x.volume??x.v??0),source};
}
async function json(url:string){const r=await fetch(url);if(!r.ok)throw new Error(`HTTP ${r.status} ${url}`);return r.json();}
export async function getTickers():Promise<Ticker[]>{
 // Prefer SunCrypto. The endpoint names and ticker fields were supplied by the user.
 for(const path of ["/tickerArr","/ticker"]){
  try{const j=await json(SUN+path);const found=rowsOf(j).map((x:any)=>normalizeTicker(x,"SunCrypto")).filter(Boolean) as Ticker[];if(found.length){activeSource="SunCrypto";return found;}}
  catch{}
 }
 // Transparent fallback keeps the scanner usable if the supplied development API is unreachable.
 const j=await json(BINANCE+"/api/v3/ticker/24hr");
 const found=(j as any[]).filter(x=>String(x.symbol).endsWith("USDT")).map(x=>normalizeTicker(x,"Binance")).filter(Boolean) as Ticker[];
 if(!found.length)throw new Error("No supported ticker data received from SunCrypto or Binance");
 activeSource="Binance";return found;
}
export function getActiveSource(){return activeSource;}
function normalizeCandles(j:any):Candle[]{
 const a=Array.isArray(j)?j:(j?.data??j?.result??j?.klines??[]);
 if(!Array.isArray(a))return [];
 return a.map((x:any)=>Array.isArray(x)?({time:Number(x[0]),open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:Number(x[5])}):({
  time:Number(x.time??x.openTime??x.t),open:Number(x.open??x.o),high:Number(x.high??x.h),low:Number(x.low??x.l),close:Number(x.close??x.c),volume:Number(x.volume??x.v)
 })).filter((c:Candle)=>[c.open,c.high,c.low,c.close].every(Number.isFinite)&&c.close>0);
}
export async function getCandles(symbol:string,interval="1h",limit=250):Promise<Candle[]>{
 // Try common REST parameter names against the documented kline route.
 const urls=[
  `${SUN}/kline?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`,
  `${SUN}/kline?symbol=${encodeURIComponent(symbol)}&period=${interval}&limit=${limit}`,
  `${SUN}/kline?contract=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`
 ];
 for(const u of urls){try{const c=normalizeCandles(await json(u));if(c.length>30)return c;}catch{}}
 // Binance candle fallback only when SunCrypto kline response cannot be parsed.
 const c=normalizeCandles(await json(`${BINANCE}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`));
 if(c.length<30)throw new Error("Kline data unavailable or response format not recognized");
 return c;
}
export async function getUsdInr():Promise<number>{try{const j=await json("https://open.er-api.com/v6/latest/USD");return Number(j.rates?.INR)||84;}catch{return 84;}}
