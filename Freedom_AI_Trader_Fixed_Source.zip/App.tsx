import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, RefreshControl, SafeAreaView, StatusBar, StyleSheet, Text, View } from "react-native";
import { getMarketCoins, Coin } from "./src/market";
import { rankCoins } from "./src/signals";

export default function App() {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [message, setMessage] = useState("Market data load ho raha hai...");

  async function load() {
    try {
      setMessage("SunCrypto market data check ho raha hai...");
      const data = await getMarketCoins();
      setCoins(data);
      setMessage(data.length ? `Updated: ${new Date().toLocaleTimeString()}` : "Abhi market data available nahi hai.");
    } catch {
      setMessage("Data load nahi hua. Internet check karke refresh karein.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => { load(); }, []);
  const ranked = useMemo(() => rankCoins(coins), [coins]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#080808" />
      <FlatList
        data={ranked.slice(0, 10)}
        keyExtractor={(item) => item.symbol}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor="#d6b45b" />}
        ListHeaderComponent={
          <View>
            <Text style={styles.brand}>FREEDOM AI TRADER</Text>
            <Text style={styles.sub}>MARKET SCANNER · INR VIEW</Text>
            <View style={styles.hero}>
              <Text style={styles.heroLabel}>BEST PRELIMINARY CANDIDATE</Text>
              <Text style={styles.heroCoin}>{ranked[0]?.symbol ?? "—"}</Text>
              <Text style={styles.heroText}>{ranked[0] ? `24h change: ${ranked[0].change24h.toFixed(2)}%` : "Market data ka intezar hai"}</Text>
            </View>
            <Text style={styles.section}>TOP 10 WATCHLIST</Text>
            <Text style={styles.status}>{loading ? "Loading..." : message}</Text>
            {loading && <ActivityIndicator color="#d6b45b" style={{ margin: 18 }} />}
          </View>
        }
        renderItem={({ item, index }) => (
          <View style={styles.row}>
            <Text style={styles.rank}>{index + 1}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.symbol}>{item.symbol}</Text>
              <Text style={styles.muted}>24h volume: {formatNumber(item.volume24h)}</Text>
            </View>
            <Text style={[styles.change, { color: item.change24h >= 0 ? "#68d391" : "#ff7777" }]}>
              {item.change24h >= 0 ? "+" : ""}{item.change24h.toFixed(2)}%
            </Text>
          </View>
        )}
        ListEmptyComponent={!loading ? <Text style={styles.empty}>Koi coin data nahi mila. Neeche pull karke refresh karein.</Text> : null}
        ListFooterComponent={
          <Text style={styles.disclaimer}>
            IMPORTANT: Ye early-stage market scanner hai, guaranteed buy/sell signal nahi. Ranking sirf available 24-hour ticker data par based hai. Entry, stop-loss, targets, EMA/RSI/Supertrend confirmation, backtesting aur accuracy validation abhi complete nahi hain. Trading se pehle khud verify karein.
          </Text>
        }
        contentContainerStyle={styles.content}
      />
    </SafeAreaView>
  );
}

function formatNumber(n: number) {
  if (!Number.isFinite(n)) return "—";
  return n >= 1_000_000 ? (n / 1_000_000).toFixed(2) + "M" : n >= 1_000 ? (n / 1_000).toFixed(2) + "K" : n.toFixed(2);
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#080808" },
  content: { padding: 16, paddingBottom: 30 },
  brand: { color: "#e3c36a", fontSize: 23, fontWeight: "900", letterSpacing: 1.2, marginTop: 10 },
  sub: { color: "#aaa", fontSize: 11, letterSpacing: 2, marginTop: 5, marginBottom: 18 },
  hero: { backgroundColor: "#17140b", borderColor: "#8b7135", borderWidth: 1, borderRadius: 14, padding: 18, marginBottom: 22 },
  heroLabel: { color: "#c9ad62", fontSize: 11, fontWeight: "700", letterSpacing: 1 },
  heroCoin: { color: "#fff", fontSize: 32, fontWeight: "900", marginTop: 8 },
  heroText: { color: "#ccc", marginTop: 5 },
  section: { color: "#e3c36a", fontSize: 16, fontWeight: "800", marginBottom: 10 },
  status: { color: "#aaa", fontSize: 12, marginBottom: 10 },
  row: { flexDirection: "row", alignItems: "center", backgroundColor: "#151515", borderRadius: 10, padding: 13, marginBottom: 8, borderWidth: 1, borderColor: "#292929" },
  rank: { color: "#d6b45b", fontWeight: "900", width: 28, fontSize: 16 },
  symbol: { color: "#fff", fontWeight: "800", fontSize: 15 },
  muted: { color: "#888", fontSize: 11, marginTop: 3 },
  change: { fontWeight: "800", fontSize: 14 },
  empty: { color: "#aaa", textAlign: "center", padding: 20 },
  disclaimer: { color: "#999", fontSize: 11, lineHeight: 17, marginTop: 18, padding: 12, backgroundColor: "#141414", borderRadius: 8 }
});