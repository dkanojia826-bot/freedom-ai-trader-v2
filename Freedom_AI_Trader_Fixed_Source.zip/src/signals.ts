import { Coin } from "./market";

// Preliminary watchlist score only; it is not a validated trading signal.
export function rankCoins(coins: Coin[]): Coin[] {
  return [...coins]
    .filter((coin) => Number.isFinite(coin.change24h) && Number.isFinite(coin.volume24h))
    .sort((a, b) => score(b) - score(a));
}

function score(coin: Coin): number {
  const momentum = Math.max(-20, Math.min(20, coin.change24h));
  const volume = Math.log10(Math.max(1, coin.volume24h));
  return momentum + volume * 0.25;
}