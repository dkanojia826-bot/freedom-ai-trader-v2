export type Coin = {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
};

const SUNCRYPTO_BASE = "https://sckt5-dev.suncrypto.in/api";

function asNumber(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

export async function getMarketCoins(): Promise<Coin[]> {
  const response = await fetch(`${SUNCRYPTO_BASE}/tickerArr`, {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) throw new Error(`SunCrypto HTTP ${response.status}`);
  const payload: any = await response.json();
  const rows = Array.isArray(payload) ? payload : Array.isArray(payload?.data) ? payload.data : [];
  return rows.map((row: any) => {
    const rawSymbol = String(row.s ?? row.symbol ?? row.market ?? "");
    const symbol = rawSymbol.replace(/[-_/]?INR$/i, "").replace(/[-_/]?USDT$/i, "").toUpperCase();
    return {
      symbol,
      price: asNumber(row.c ?? row.price ?? row.lastPrice),
      change24h: asNumber(row.P ?? row.change24h ?? row.priceChangePercent),
      volume24h: asNumber(row.q ?? row.v ?? row.quoteVolume ?? row.volume)
    };
  }).filter((coin: Coin) => coin.symbol.length > 0 && coin.price > 0);
}