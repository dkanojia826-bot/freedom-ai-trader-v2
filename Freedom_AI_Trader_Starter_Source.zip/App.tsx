import React, { useEffect, useState } from "react";
import { ActivityIndicator, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { loadMarket } from "./src/market";
import { rankCoins } from "./src/signals";
import { RankedCoin } from "./src/types";

const gold="#E8BD58", bg="#080B12", panel="#131A26", muted="#9AA5B5";
const inr=(n:number)=>"₹"+Math.round(n).toLocaleString("en-IN");

export default function App(){
  const [items,setItems]=useState<RankedCoin[]>([]);
  const [rate,setRate]=useState(0);
  const [source,setSource]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [updated,setUpdated]=useState("");
  async function refresh(){
    setBusy(true); setError("");
    try{
      const data=await loadMarket();
      setRate(data.rate); setSource(data.source);
      setItems(rankCoins(data.coins,data.rate));
      setUpdated(new Date().toLocaleString("en-IN"));
    }catch(e:any){setError(e?.message||"Market data unavailable");}
    finally{setBusy(false);}
  }
  useEffect(()=>{refresh();},[]);
  const best=items.find(x=>x.label==="WATCH FOR ENTRY" && x.risk!=="HIGH");
  const top=items.slice(0,10);
  return <SafeAreaView style={s.root}>
    <StatusBar barStyle="light-content" backgroundColor={bg}/>
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.brand}>FREEDOM <Text style={{color:gold}}>AI TRADER</Text></Text>
      <Text style={s.sub}>MARKET SCANNER • INR • MANUAL TRADING</Text>
      <View style={s.banner}>
        <Text style={s.bannerTitle}>BEST COIN TO WATCH</Text>
        {best ? <><Text style={s.coin}>{best.symbol}/USDT</Text><Text style={s.score}>Score {best.score}/100 • {best.risk} RISK</Text><Text style={s.detail}>Indicative entry: {inr(best.entry)}</Text><Text style={s.detail}>Stop: {inr(best.stop)}   Target 1: {inr(best.target1)}</Text><Text style={s.note}>Watchlist candidate only. Confirm candle indicators before any trade.</Text></>
        : <Text style={s.detail}>No high-confidence candidate right now. NO TRADE.</Text>}
      </View>
      <View style={s.row}>
        <Text style={s.section}>TOP 10 COINS</Text>
        <TouchableOpacity onPress={refresh} style={s.refresh}><Text style={s.refreshText}>{busy?"SCANNING…":"REFRESH"}</Text></TouchableOpacity>
      </View>
      {busy && <ActivityIndicator color={gold} size="large" />}
      {error!=="" && <Text style={s.error}>{error}</Text>}
      {top.map((c,i)=><View key={c.symbol} style={s.card}>
        <View style={{flex:1}}>
          <Text style={s.coinName}>{i+1}. {c.symbol}/USDT</Text>
          <Text style={s.detail}>{inr(c.entry)} • 24h {c.change24h.toFixed(2)}%</Text>
          <Text style={s.note}>{c.reason}</Text>
        </View>
        <View style={s.right}><Text style={s.score}>{c.score}/100</Text><Text style={s.risk}>{c.label}</Text></View>
      </View>)}
      <View style={s.info}>
        <Text style={s.section}>DATA STATUS</Text>
        <Text style={s.detail}>Source: {source||"Connecting…"}</Text>
        <Text style={s.detail}>USDT/INR: {rate?rate.toFixed(2):"—"}</Text>
        <Text style={s.detail}>Updated: {updated||"—"}</Text>
      </View>
      <Text style={s.disclaimer}>Important: This starter build ranks coins using 24-hour ticker data only. It does not yet calculate live EMA 7/30/200, RSI, Supertrend, candle support/resistance, token unlocks, team/backers, or reliable future profit times. No accuracy or profit is guaranteed. Do not trade from this preliminary score alone.</Text>
    </ScrollView>
  </SafeAreaView>;
}
const s=StyleSheet.create({
 root:{flex:1,backgroundColor:bg},content:{padding:18,paddingBottom:40},
 brand:{color:"#fff",fontSize:25,fontWeight:"900",letterSpacing:1},sub:{color:muted,fontSize:10,letterSpacing:1.5,marginTop:4,marginBottom:18},
 banner:{backgroundColor:"#171D29",borderColor:gold,borderWidth:1,borderRadius:14,padding:16,marginBottom:22},
 bannerTitle:{color:gold,fontWeight:"800",fontSize:12,letterSpacing:1},coin:{color:"#fff",fontSize:23,fontWeight:"900",marginTop:9},score:{color:gold,fontWeight:"800",fontSize:14},detail:{color:"#E0E5ED",fontSize:13,marginTop:6},note:{color:muted,fontSize:11,marginTop:7,lineHeight:16},
 row:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginBottom:12},
 section:{color:gold,fontSize:13,fontWeight:"900",letterSpacing:1},
 refresh:{borderColor:gold,borderWidth:1,borderRadius:8,paddingVertical:8,paddingHorizontal:12},refreshText:{color:gold,fontWeight:"800",fontSize:11},
 card:{backgroundColor:panel,borderRadius:11,padding:13,marginBottom:9,flexDirection:"row",alignItems:"center"},
 coinName:{color:"#fff",fontWeight:"800",fontSize:15},right:{alignItems:"flex-end",marginLeft:10},risk:{color:muted,fontSize:10,fontWeight:"700",marginTop:4},
 info:{backgroundColor:panel,borderRadius:12,padding:14,marginTop:16},
 error:{color:"#FF7777",marginVertical:10},disclaimer:{color:"#D6B66C",fontSize:11,lineHeight:17,marginTop:18}
});