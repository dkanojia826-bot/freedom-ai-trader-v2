FREEDOM AI TRADER — STARTER SOURCE

Is ZIP ko GitHub repo mein upload karke Android APK build kiya ja sakta hai.

Abhi implemented:
- Standalone Expo Android app scaffold
- SunCrypto /api/tickerArr primary ticker source
- CoinGecko ticker fallback
- USDT to INR conversion
- 24h ticker-based coin ranking and Top 10
- Indicative entry/stop/targets (not a trade guarantee)
- EMA, RSI and Supertrend calculation helper functions

Abhi complete nahi:
- SunCrypto kline integration (kline endpoint ke exact request/response schema ki zaroorat)
- EMA 7/30/200, RSI, Supertrend live signals from candle history
- Volume confirmation, support/resistance, BTC trend
- Token supply/unlocks, backers, team and community verification
- Historical backtesting and live paper-trading accuracy report
- Trade journal and alerts
- Reliable future signal/target time prediction (cannot be guaranteed)

IMPORTANT:
This is the first development build, NOT the finished trading product.
The score is only a preliminary 24-hour ticker ranking. Never use it alone to place a trade.
50% accuracy is a testing target, not a promise. Actual accuracy must be measured with out-of-sample backtests and paper trading after fees/slippage.

SunCrypto docs previously shared:
Base: https://sckt5-dev.suncrypto.in/api
Known endpoint: /tickerArr
Known fields: s, c, P, h, l, v, q (among others)
The user has a SunCrypto market info key, but authentication requirements and kline parameters were not confirmed. Do not embed private keys in app source.
