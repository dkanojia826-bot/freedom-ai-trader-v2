import { MarketCoin } from "./types";

const SUN_BASE = "https://sckt5-dev.suncrypto.in/api";

function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export async function fetchSunCrypto(): Promise<MarketCoin[]> {
  const response = await fetch(`${SUN_BASE}/tickerArr`, {
    method: "GET",
    headers: { "Accept": "application/json" }
  });
  if (!response.ok) throw new Error(`SunCrypto HTTP ${response.status}`);
  const json = await response.json();
  if (json?.status !== "success" || !Array.isArray(json?.data)) {
    throw new Error("SunCrypto ticker response format changed");
  }

  const unique = new Map<string, MarketCoin>();
  for (const row of json.data) {
    const raw = String(row?.s ?? "").toUpperCase();
    if (!raw.endsWith("USDT")) continue;
    const symbol = raw.slice(0, -4);
    if (!symbol || unique.has(symbol)) continue;
    const priceUsdt = num(row?.c);
    if (priceUsdt <= 0) continue;
    unique.set(symbol, {
      symbol, priceUsdt,
      change24h: num(row?.P),
      high24h: num(row?.h),
      low24h: num(row?.l),
      quoteVolume: num(row?.q),
      source: "SunCrypto"
    });
  }
  if (!unique.size) throw new Error("No usable USDT ticker pairs received");
  return [...unique.values()];
}

export async function fetchCoinGeckoFallback(): Promise<MarketCoin[]> {
  const url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=100&page=1&sparkline=false";
  const response = await fetch(url);
  if (!response.ok) throw new Error(`CoinGecko HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows)) throw new Error("CoinGecko response format changed");
  return rows.map((r: any) => ({
    symbol: String(r.symbol ?? "").toUpperCase(),
    priceUsdt: Number(r.current_price) || 0,
    change24h: Number(r.price_change_percentage_24h) || 0,
    high24h: Number(r.high_24h) || 0,
    low24h: Number(r.low_24h) || 0,
    quoteVolume: Number(r.total_volume) || 0,
    source: "CoinGecko" as const
  })).filter((c: MarketCoin) => c.symbol && c.priceUsdt > 0);
}

export async function fetchUsdtInr(): Promise<number> {
  const r = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=inr");
  if (!r.ok) throw new Error("Could not get USDT/INR conversion");
  const j = await r.json();
  const rate = Number(j?.tether?.inr);
  if (!Number.isFinite(rate) || rate <= 0) throw new Error("Invalid USDT/INR rate");
  return rate;
}

export async function loadMarket(): Promise<{coins: MarketCoin[]; rate: number; source: string}> {
  let coins: MarketCoin[] = [];
  let source = "SunCrypto";
  try {
    coins = await fetchSunCrypto();
  } catch {
    source = "CoinGecko backup";
    coins = await fetchCoinGeckoFallback();
  }
  const rate = await fetchUsdtInr();
  return { coins, rate, source };
}