export type MarketCoin = {
  symbol: string;
  priceUsdt: number;
  change24h: number;
  high24h: number;
  low24h: number;
  quoteVolume: number;
  source: "SunCrypto" | "CoinGecko";
};
export type RankedCoin = MarketCoin & {
  score: number;
  label: string;
  risk: "LOW" | "MEDIUM" | "HIGH";
  entry: number;
  stop: number;
  target1: number;
  target2: number;
  estimatedWindow: string;
  reason: string;
};