import { MarketCoin, RankedCoin } from "./types";

export function rankCoins(coins:MarketCoin[], usdtInr:number):RankedCoin[] {
  const ranked = coins.map(c=>{
    const range = Math.max(c.high24h-c.low24h, c.priceUsdt*0.001);
    const rangePosition = Math.max(0,Math.min(1,(c.priceUsdt-c.low24h)/range));
    const momentum = Math.max(-1,Math.min(1,c.change24h/8));
    const volumeScore = Math.min(1,Math.log10(Math.max(c.quoteVolume,1))/10);
    const score = Math.round(50 + momentum*20 + (rangePosition-.5)*20 + volumeScore*10);
    const risk = Math.abs(c.change24h)>12 ? "HIGH" : Math.abs(c.change24h)>5 ? "MEDIUM" : "LOW";
    const entry = c.priceUsdt*usdtInr;
    const stopPct = risk==="HIGH" ? .035 : risk==="MEDIUM" ? .025 : .018;
    const targetPct = stopPct*1.8;
    const label = score>=72 && risk!=="HIGH" ? "WATCH FOR ENTRY" : score>=60 ? "POTENTIAL" : "WAIT";
    return {
      ...c, score, risk, label,
      entry, stop:entry*(1-stopPct),
      target1:entry*(1+targetPct),
      target2:entry*(1+targetPct*1.7),
      estimatedWindow:"Not predictable from ticker snapshot",
      reason: c.change24h>0 ? "Positive 24h momentum; needs candle confirmation" : "Momentum is weak/negative; wait for confirmation"
    } as RankedCoin;
  });
  return ranked.sort((a,b)=>b.score-a.score);
}