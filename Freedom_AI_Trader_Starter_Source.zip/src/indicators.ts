export type Candle = { open:number; high:number; low:number; close:number; volume:number; time:number };

export function ema(values:number[], period:number): number[] {
  if (period <= 0 || values.length < period) return [];
  const k = 2 / (period + 1);
  const out:number[] = [];
  let prev = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  out.push(prev);
  for (let i=period;i<values.length;i++) {
    prev = values[i] * k + prev * (1-k);
    out.push(prev);
  }
  return out;
}

export function rsi(values:number[], period=14): number | null {
  if (values.length <= period) return null;
  let gains=0, losses=0;
  for(let i=1;i<=period;i++){
    const d=values[i]-values[i-1];
    if(d>=0) gains+=d; else losses-=d;
  }
  let avgGain=gains/period, avgLoss=losses/period;
  for(let i=period+1;i<values.length;i++){
    const d=values[i]-values[i-1];
    avgGain=(avgGain*(period-1)+Math.max(d,0))/period;
    avgLoss=(avgLoss*(period-1)+Math.max(-d,0))/period;
  }
  if(avgLoss===0) return 100;
  return 100-(100/(1+avgGain/avgLoss));
}

export function supertrendDirection(candles:Candle[], period=10, multiplier=3): "UP"|"DOWN"|"INSUFFICIENT_DATA" {
  if(candles.length < period+2) return "INSUFFICIENT_DATA";
  let direction:"UP"|"DOWN"="UP";
  let prevUpper=0, prevLower=0, atr=0;
  const trs:number[]=[];
  for(let i=1;i<candles.length;i++){
    const c=candles[i], p=candles[i-1];
    trs.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));
  }
  atr=trs.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<trs.length;i++){
    atr=(atr*(period-1)+trs[i])/period;
    const c=candles[i+1];
    const mid=(c.high+c.low)/2;
    const upper=mid+multiplier*atr, lower=mid-multiplier*atr;
    const finalUpper=prevUpper===0?upper:(upper<prevUpper||candles[i].close>prevUpper?upper:prevUpper);
    const finalLower=prevLower===0?lower:(lower>prevLower||candles[i].close<prevLower?lower:prevLower);
    if(direction==="DOWN" && c.close>finalUpper) direction="UP";
    else if(direction==="UP" && c.close<finalLower) direction="DOWN";
    prevUpper=finalUpper; prevLower=finalLower;
  }
  return direction;
}